### Print()

De eerste functie die we zullen leren is de print() functie. Deze functie zal printen wat er tussen de haakjes staat. 

Eerst leren we om 'strings' (=tekst) te printen. Dit doe je door de tekst tussen twee "" te zetten.

### Opdracht
Kopieer onderstaande code en voer hem uit.

```python
print("Hello world")
```
