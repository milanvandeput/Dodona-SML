_en_: This is the most basic exercise; read the input and print it out again.

_nl:_ Dit is een basisoefening; lees de input en print die terug uit.

(Deze about informatie wordt getoond voor alle talen, omdat er geen gelokaliseerde alternatieven zijn zoals bv. `readme.nl.md`)
