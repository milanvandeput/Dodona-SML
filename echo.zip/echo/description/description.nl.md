Je krijgt één regel invoer en je moet eenvoudig weg deze invoer herhalen. Je moet dus een programma schrijven dat als echo fungeert.

![echo cave](media/Echo_Caves.jpg){:height="50%" width="50%"}

### Invoer

Eén regel tekst zonder verdere restricties.

### Uitvoer

Dezelfde tekst als je hebt ingelezen bij de invoer.

### Voorbeeld

**Invoer:**

    42

**Uitvoer:**

    42

### Voorbeeld

**Invoer:**

    ECHO

**Uitvoer:**

    ECHO
