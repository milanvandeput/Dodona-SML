You receive one line of input and you simply have to repeat this input. You have to write a program which functions as an echo.

![echo cave](media/Echo_Caves.jpg){:height="50%" width="50%"}

### Input

One line of text without any further restrictions.

### Output

The same text which can be read under input.

### Example

**Input:**

      42

**Output:**

      42

### Example

**Input:**

      ECHO

**Output:**

      ECHO
